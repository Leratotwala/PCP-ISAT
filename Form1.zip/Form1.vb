﻿Public Class Form1
    'DECLEARING VARIABLES
    Const decVatRate As Decimal = 0.15
    Dim intchkBoxes As Integer
    Dim decPromotionalDiscount As Decimal
    Dim decSubCost As Decimal
    Dim decVatAmount As Decimal
    Dim decTotalAmount As Decimal
    Dim decMainProduct As Decimal
    Dim decAccessories As Decimal



    Function calcMainProduct(ByVal decMainProduct As Decimal) As Decimal
        'FUNCTION FOR CALCULATING TOTAL PRODUCTS
        If radLaptop.Checked = True Then
            decMainProduct = 3500.0
        ElseIf radDesktopComputer.Checked = True Then
            decMainProduct = 3600.0
        ElseIf radTablet.Checked = True Then
            decMainProduct = 2000.0
        ElseIf radSmartphone.Checked = True Then
            decMainProduct = 2500.0
        End If
        Return CDec(decMainProduct)
    End Function


    Sub DisplayMainProduct(ByVal decMainProduct As Decimal)
        'Subrotine for MAINPRODUCT Display 
        lstQoute.Text = decMainProduct.ToString("C2")
    End Sub


    Function calcAccessories(ByVal decAccessories As Decimal) As Decimal
        'FUNCTION FOR CALCULATING ACCESSORIES 
        If chkLaptopBag.Checked = True Then
            decAccessories += 350.0
        End If
        If chkKeyboard.Checked = True Then
            decAccessories += 40.0
        End If
        If chkWirelessMouse.Checked = True Then
            decAccessories += 250.0
        End If
        If chkUSB.Checked = True Then
            decAccessories += 125.0
        End If
        Return CDec(decAccessories)
    End Function

    Sub DisplayAccessories(ByVal decAccessories As Decimal)
        'SUBROTINE FOR ACCESSORIES DISPLAY 
        lstQoute.Text = decAccessories.ToString("C2")
    End Sub


    Function calcSubCost(ByVal decMainProduct As Decimal, ByVal decAccessoies As Decimal) As Decimal
        'FUNCTION FOR CALCULATING SUBCOST
        Dim decSubCost As Decimal

        decSubCost = decMainProduct + decAccessories
        Return CDec(decSubCost)
    End Function

    Sub DisplaySubCost(ByVal decMainProduct As Decimal, ByVal decAccessories As Decimal, ByVal decSubCost As Decimal)
        'SUBROTINE FOR SUBCOST DISPLAY
        lstQoute.Text = decSubCost.ToString("C2")
    End Sub


    Function calcPromotionalDiscount(ByVal decPromotionalDiscount As Decimal, ByVal decSubCost As Decimal) As Decimal
        'FUNTION FOR CALCULATING PROMOTINAL DISCOUNT 
        If chkKeyboard.Checked = False Then
            intchkBoxes = 0
        ElseIf chkLaptopBag.Checked = False Then
            intchkBoxes = 0
        ElseIf chkUSB.Checked = False Then
            intchkBoxes = 0
        ElseIf chkWirelessMouse.Checked = False Then
            intchkBoxes = 0
        End If

        If chkKeyboard.Checked = True Then
            intchkBoxes = 1
        ElseIf chkLaptopBag.Checked = True Then
            intchkBoxes = 1
        ElseIf chkUSB.Checked = True Then
            intchkBoxes = 1
        ElseIf chkWirelessMouse.Checked = True Then
            intchkBoxes = 1
        End If


        If chkKeyboard.Checked = True And chkLaptopBag.Checked = True Then
            intchkBoxes = 2
        ElseIf chkKeyboard.Checked = True And chkUSB.Checked = True Then
            intchkBoxes = 2
        ElseIf chkKeyboard.Checked = True And chkWirelessMouse.Checked = True Then
            intchkBoxes = 2
        ElseIf chkLaptopBag.Checked = True And chkWirelessMouse.Checked = True Then
            intchkBoxes = 2
        ElseIf chkLaptopBag.Checked = True And chkUSB.Checked = True Then
            intchkBoxes = 2
        ElseIf chkUSB.Checked = True And chkWirelessMouse.Checked = True Then
            intchkBoxes = 2
        End If


        If chkLaptopBag.Checked = True And chkWirelessMouse.Checked = True And chkKeyboard.Checked = True Then
            intchkBoxes = 3
        ElseIf chkLaptopBag.Checked = True And chkWirelessMouse.Checked = True And chkUSB.Checked = True Then
            intchkBoxes = 3
        ElseIf chkLaptopBag.Checked = True And chkUSB.Checked = True And chkKeyboard.Checked = True Then
            intchkBoxes = 3
        ElseIf chkWirelessMouse.Checked = True And chkWirelessMouse.Checked = True And chkKeyboard.Checked = True Then
            intchkBoxes = 3

        End If


        If radDesktopComputer.Checked And radLaptop.Checked And radSmartphone.Checked And radTablet.Checked And intchkBoxes = 0 Then
            decPromotionalDiscount = 0
        End If
        If radDesktopComputer.Checked And intchkBoxes = 0 Then
            decPromotionalDiscount = 0
        End If
        If radDesktopComputer.Checked And intchkBoxes = 1 Then
            decPromotionalDiscount = decSubCost * 0.04
        End If
        If radDesktopComputer.Checked And intchkBoxes = 2 Then
            decPromotionalDiscount = decSubCost * 0.06
        End If

        If radLaptop.Checked And chkKeyboard.Checked And chkLaptopBag.Checked Then
            decPromotionalDiscount = (40.0 + 3500.0 + 350.0) * 0.14
        End If
        If radSmartphone.Checked And intchkBoxes = 0 Then
            decPromotionalDiscount = 0
        End If
        If radSmartphone.Checked And intchkBoxes = 1 Then
            decPromotionalDiscount = decSubCost * 0.04
        End If
        If radSmartphone.Checked And intchkBoxes = 2 Then
            decPromotionalDiscount = decSubCost * 0.06
        End If
        If radTablet.Checked And intchkBoxes = 1 Then
            decPromotionalDiscount = 0
        End If
        If radTablet.Checked And intchkBoxes = 1 Then
            decPromotionalDiscount = decSubCost * 0.04
        End If
        If radTablet.Checked And intchkBoxes = 2 Then
            decPromotionalDiscount = decSubCost * 0.06
        End If
        Return CDec(decPromotionalDiscount)
    End Function

    Sub DisplayPromotionalDiscount(ByVal decPromotionalDiscount As Decimal)
        'SUBROTINE FOR PROMOTIONAL DISCOUNT DISPLAY 
        lstQoute.Text = decPromotionalDiscount.ToString("C2")
    End Sub

    Function calcVatAmount(ByVal decVatAmount As Decimal, ByVal decSubCost As Decimal) As Decimal
        'FUNCTION FOR CALCULATING VAT 
        If radDesktopComputer.Checked = True Then
            decVatAmount = 3600.0 * 0.15
        ElseIf radLaptop.Checked = True Then
            decVatAmount = 3500.0 * 0.15
        ElseIf radSmartphone.Checked = True Then
            decVatAmount = 2500.0 * 0.15
        ElseIf radTablet.Checked = True Then
            decVatAmount = 2000.0 * 0.15
        End If

        If chkLaptopBag.Checked = True Then
            decVatAmount = 350.0 * 0.15
        End If
        If chkKeyboard.Checked = True Then
            decVatAmount = 40.0 * 0.15
        End If
        If chkUSB.Checked = True Then
            decVatAmount = 125.0 * 0.15
        End If
        If chkWirelessMouse.Checked = True Then
            decVatAmount = 250.0 * 0.15
        End If
        decVatAmount = decSubCost * decVatRate

        Return CDec(decVatAmount)

    End Function

    Sub DisplayVatAmount(ByVal decVatAmount As Decimal)
        'SUBROTINE FOR VAT
        lstQoute.Text = decVatAmount.ToString("C2")
    End Sub

    Function calcTotalAmount(ByVal decTotalAmount As Decimal) As Decimal
        'FUNCTION FOR CALACULATING TOTAL AMOUNT
        If radDesktopComputer.Checked = True Then
            decTotalAmount = 3600.0 + decVatAmount
        ElseIf radLaptop.Checked = True Then
            decTotalAmount = 3500.0 + decVatAmount
        ElseIf radSmartphone.Checked = True Then
            decTotalAmount = 2500.0 + decVatAmount
        ElseIf radTablet.Checked = True Then
            decTotalAmount = 2000.0 + decVatAmount
        End If

        If chkLaptopBag.Checked = True Then
            decTotalAmount = 350.0 + decVatAmount
        ElseIf chkKeyboard.Checked = True Then
            decTotalAmount = 40.0 + decVatAmount
        ElseIf chkUSB.Checked = True Then
            decTotalAmount = 125.0 + decVatAmount
        ElseIf chkWirelessMouse.Checked = True Then
            decTotalAmount = 250.0 + decVatAmount
        End If

        decTotalAmount = decMainProduct + decAccessories + decVatAmount - decPromotionalDiscount

        Return CDec(decTotalAmount)
    End Function

    Sub DisplayTotalAmount(ByVal decTotalAmount As Decimal)
        'SUBROTINE FOR TOTALAMOUNT 
        lstQoute.Text = decTotalAmount.ToString("C2")
    End Sub

    Private Sub btnQoute_Click(sender As Object, e As EventArgs) Handles btnQoute.Click
        'DECLARING AND CONERTING THE VARIABLES
        Dim strSurname As String = txtSurname.Text
        Dim strName As String = txtName.Text
        Dim strEmail As String = txtEmail.Text
        Dim strTelno As String = mtbTelNo.Text
        Dim strMainProduct As String
        Dim strAccess As String

        Dim decMainProduct As Decimal
        Dim decAccessories As Decimal
        Dim cecSubCost As Decimal
        Dim decPromotinalDiscount As Decimal
        Dim decVatAmount As Decimal
        Dim decTotalAmount As Decimal


        decMainProduct = calcMainProduct(decMainProduct)
        Call DisplayMainProduct(decMainProduct)
        decAccessories = calcAccessories(decAccessories)
        Call DisplayAccessories(decAccessories)
        decSubCost = calcSubCost(decMainProduct, decAccessories)
        Call DisplaySubCost(decMainProduct, decAccessories, decSubCost)
        decPromotionalDiscount = calcPromotionalDiscount(decPromotionalDiscount, decSubCost)
        Call DisplayPromotionalDiscount(decPromotionalDiscount)
        decVatAmount = calcVatAmount(decVatAmount, decSubCost)
        Call DisplayVatAmount(decVatAmount)
        decTotalAmount = calcTotalAmount(decTotalAmount)
        Call DisplayTotalAmount(decTotalAmount)



        If txtName.Text = " " Then
            MessageBox.Show("PLEASE ENTER YOUR NAME ")
            txtName.Focus()
        End If
        If txtSurname.Text = "" Then
            MessageBox.Show("please enter your surname")
            txtSurname.Focus()
        End If
        If mtbTelNo.Text = "" Then
            MessageBox.Show("PLEASE ENTER YOUR TELEPHONE NUMBER ")
            mtbTelNo.Focus()
        End If
        If txtEmail.Text = "" Then
            MessageBox.Show("please enter your email address")
            txtEmail.Focus()
        End If


        If radDesktopComputer.Checked = True Then
            strMainProduct = " Desktop Computer"
        End If
        If radLaptop.Checked = True Then
            strMainProduct = "Laptop"
        End If
        If radSmartphone.Checked = True Then
            strMainProduct = "Smartphone "
        End If
        If radTablet.Checked = True Then
            strMainProduct = "Tablet"
        End If

        If chkKeyboard.Checked = True Then
            strAccess += "pro keyboard "
        End If
        If chkLaptopBag.Checked = True Then
            strAccess += "pro LaptopBag"
        End If
        If chkUSB.Checked = True Then
            strAccess += "pro USB "
        End If
        If chkWirelessMouse.Checked = True Then
            strAccess += "pro Wireless Mouse "
        End If

        'DISPLAY QUOTE 
        lstQoute.Items.Add("QUOTE BY:   TECHNOVA DIGITAL PRO ")
        lstQoute.Items.Add("=========================================================================================")
        lstQoute.Items.Add("")
        lstQoute.Items.Add("Surname:                                                " & strSurname)
        lstQoute.Items.Add("Name:                                                   " & strName)
        lstQoute.Items.Add("Tel Number:                                             " & strTelno)
        lstQoute.Items.Add("Email:                                                  " & strEmail)
        lstQoute.Items.Add("=========================================================================================")
        lstQoute.Items.Add("")
        lstQoute.Items.Add("MainProduct:                                            " & strMainProduct)
        lstQoute.Items.Add("Accessories:                                            " & strAccess)
        lstQoute.Items.Add("=========================================================================================")
        lstQoute.Items.Add("")
        lstQoute.Items.Add("MainProduct Price:                                      " & decMainProduct.ToString("C2"))
        lstQoute.Items.Add("Accessories Price:                                      " & decAccessories.ToString("C2"))
        lstQoute.Items.Add("Combined Price:                                         " & decSubCost.ToString("C2"))
        lstQoute.Items.Add("=========================================================================================")
        lstQoute.Items.Add("")
        lstQoute.Items.Add("Promotinal Discount:                                    " & decPromotionalDiscount.ToString("C2"))
        lstQoute.Items.Add("Vat Amount:                                             " & decVatAmount.ToString("C2"))
        lstQoute.Items.Add("=========================================================================================")
        lstQoute.Items.Add("Total Amount:                                           " & decTotalAmount.ToString("C2"))
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'CLEARING THE HANDLES
        txtEmail.Clear()
        txtName.Clear()
        txtSurname.Clear()
        mtbTelNo.Clear()
        radDesktopComputer.Checked = False
        radLaptop.Checked = False
        radSmartphone.Checked = False
        radTablet.Checked = False
        chkKeyboard.Checked = False
        chkLaptopBag.Checked = False
        chkUSB.Checked = False
        chkWirelessMouse.Checked = False
        lstQoute.Items.Clear()
        txtSurname.Focus()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'EXITING THE PROGRAM 
        Me.Close()
    End Sub
End Class
